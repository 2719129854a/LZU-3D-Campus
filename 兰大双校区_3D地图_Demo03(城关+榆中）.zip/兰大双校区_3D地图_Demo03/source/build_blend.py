"""Blender 4.x CLI: import the actual delivered GLBs, save editable scenes, render evidence."""
import bpy,json,os
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];reports=[]
for key in os.environ.get('LZU_RENDER_KEYS','chengguan,yuzhong').split(','):
 bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
 meta=json.loads((root/'data'/key/'scene_metadata.json').read_text());bpy.ops.import_scene.gltf(filepath=str(root/'models'/meta['model_filename']))
 scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
 imported=[o for o in scene.objects if o.type=='MESH'];report={'campus':key,'mesh_objects':len(imported),'vertices':sum(len(o.data.vertices) for o in imported),'triangles':sum(len(o.data.polygons) for o in imported),'blender':bpy.app.version_string,'glb_sha256':meta['model_sha256']};reports.append(report)
 scene.world=bpy.data.worlds.new(key+' daylight');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.70,.80,.83,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.75
 bpy.ops.object.light_add(type='AREA',location=(-600,-400,1200));light=bpy.context.object;light.name='Soft daylight';light.data.energy=10000000;light.data.shape='DISK';light.data.size=850
 bpy.ops.object.camera_add();cam=bpy.context.object;cam.name='校园全景';scene.camera=cam;cam.data.type='ORTHO';cam.data.clip_end=10000
 target=Vector((meta['view']['target'][0],-meta['view']['target'][2],0))
 cam.location=target+Vector((-900,-1100,1100)) if key=='chengguan' else target+Vector((1100,-1450,1300));cam.data.ortho_scale=1900 if key=='chengguan' else 2700;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
 scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=24;scene.cycles.use_denoising=False;scene.render.resolution_x=1600;scene.render.resolution_y=1050;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='Standard';scene.view_settings.look='None'
 scene['source_glb_sha256']=meta['model_sha256'];scene['notes']='Simplified campus exterior. Refer to individual object metadata for surveyed vs estimated fields. Geographic data © OSM contributors ODbL.'
 bpy.ops.wm.save_as_mainfile(filepath=str(root/'models'/f'lzu_{key}_demo_v3.blend'))
 scene.render.filepath=str(root/'reviews'/f'{key}_overview.png');bpy.ops.render.render(write_still=True)
 if key=='chengguan':
  p=next(p for p in meta['places'] if p['id']=='jishi');target=Vector((p['x'],-p['z'],15));cam.location=target+Vector((-125,75,75));cam.data.ortho_scale=175;cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(root/'reviews/jishi_closeup.png');scene.render.resolution_x=1400;scene.render.resolution_y=1050;bpy.ops.render.render(write_still=True)
report_path=root/'reviews/blender_import_check.json'
old_reports=json.loads(report_path.read_text()) if report_path.exists() else []
new_by_key={r['campus']:r for r in old_reports+reports};report_path.write_text(json.dumps(list(new_by_key.values()),indent=2));print(reports)
