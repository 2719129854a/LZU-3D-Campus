"""Chengguan west/east campus: retrieved footprints + photo-led landmarks."""
from geometry import *
import geometry as geo
from shapely.geometry import Polygon,LineString,Point
from shapely.ops import unary_union
from shapely import constrained_delaunay_triangles
ORIGIN=(103.860,36.046);geo.ORIGIN=ORIGIN;geo.COS=math.cos(math.radians(ORIGIN[1]));random.seed(1106)
selected=json.loads((DATA/'chengguan/selected.json').read_text());raw=json.loads((DATA/'chengguan/osm_raw.json').read_text())
def points(e):return [xy(p['lon'],p['lat']) for p in e['geometry'][:-1]]
boundaries=[points(e) for e in selected['boundaries']];campus=unary_union([Polygon(p) for p in boundaries]);buildings=selected['buildings']
def pos(e):
 p=Polygon(points(e)).centroid;return p.x,p.y
def find(oid):return next(e for e in buildings if e['id']==oid)
def sheet(g,shape,y,col):
 for t in constrained_delaunay_triangles(shape).geoms:
  v=list(t.exterior.coords)[:3]
  if area(v)<0:v.reverse()
  g.tri((v[0][0],y,v[0][1]),(v[2][0],y,v[2][1]),(v[1][0],y,v[1][1]),col)
# Deliberately modest urban context, retaining the real offset between west/east.
g=Group('terrain_campus','城关校区地面与简化城市底座',extras={'source':'OSM west way464538785; east way284557567','height':'flat estimate'})
minx,minz,maxx,maxz=campus.bounds;extent=(minx-55,minz-55,maxx+55,maxz+55)
g.prism([(extent[0],extent[1]),(extent[2],extent[1]),(extent[2],extent[3]),(extent[0],extent[3])],9.7,'#b7b5a2',y=-10)
for p in boundaries:g.prism(p,.38,'#8fa47a',y=-.30)
# Roads: intersect the original linework with the two retrieved campus areas.
roadlines=[];road_shapes=[];path_shapes=[];outer_shapes=[]
g=Group('roads','校内道路与铺装')
for e in selected['roads']:
 q=[xy(p['lon'],p['lat']) for p in e['geometry']];t=e['tags'];typ=t.get('highway','service');w=3 if typ in ('footway','path','steps') else 7 if typ=='service' else 9
 line=LineString(q)
 if t.get('area')=='yes':
  shape=Polygon(q).intersection(campus)
  if shape.is_valid and not shape.is_empty:sheet(g,shape,.20,'#c4c1af')
  continue
 shape=line.buffer(w/2,cap_style=2).intersection(campus)
 if shape.is_empty:continue
 outer_shapes.append(line.buffer(w*.73,cap_style=2).intersection(campus));(path_shapes if w<4 else road_shapes).append(shape)
 for a,b in zip(q,q[1:]):
  if campus.intersects(LineString([a,b])):roadlines.append((a,b,w))
asphalt=unary_union(road_shapes);paths=unary_union(path_shapes).difference(asphalt)
for p,y,c in [(unary_union(outer_shapes),.13,'#d1ceba'),(asphalt,.18,'#7d8987'),(paths,.19,'#c4baa3')]:sheet(g,p,y,c)
# Subtle street strips along the shared urban edges, not extra invented campus buildings.
g=Group('context','周边道路 · 环境简化')
for p in boundaries:
 ring=Polygon(p).buffer(9,join_style=2).difference(campus)
 sheet(g,ring,-.18,'#9da39b')
# Most buildings keep retrieved actual footprints. Height fields are treated as candidates.
core_buildings={284557568,511734229,284759754,292292097}
for e in buildings:
 if e['id'] in core_buildings:continue
 t=e['tags'];p=points(e);cx,cz=pos(e);local=[(x-cx,z-cz) for x,z in p];name=t.get('name',f'校园建筑 {e["id"]}')
 if name=='ligongl':name='理工楼（凌云楼）'
 try:levels=int(float(t.get('building:levels','5')))
 except ValueError:levels=5
 levels=max(2,min(levels,24));h=levels*3.35;reason='按候选楼层估计，未实测'
 if e['id']==284557995:levels=14;h=49;reason='校方基建处介绍地上14层；米制高度估计'
 try:
  hh=float(t.get('height','0').replace('m','').strip())
  if hh>0 and ('building:levels' not in t or 2.4<=hh/levels<=5):h=hh;reason='OSM height字段，尚未经现状实测'
  elif hh>0:reason='OSM height与楼层字段冲突；采用楼层估计，待核校'
 except ValueError:pass
 if '餐厅'in name:h=11;levels=3
 col='#d9d4c4' if '公寓' not in name else '#c8b9a1'
 if t.get('building')=='hospital':col='#d0d8d3';h=max(20,h)
 g=Group('cg_osm_'+str(e['id']),name,(cx,cz),extras={'osm_id':e['id'],'height_m':h,'height_basis':reason,'appearance':'simplified facade'})
 g.prism(local,h,col,collision=True);g.facade(local,h,levels);g.prism(local,.55,'#abaeaa',y=h)
 if name in ['观云楼','齐云楼','丹桂苑餐厅','理工楼（凌云楼）','兰州大学体育馆','精诚楼']:
  place(g,name,'西区地标' if cx<50 else '东区建筑',reason+'；轮廓来自OSM，立面简化。',max(150,h*3.6))
# Jishi Library: low stone wings, a broad arched entrance and the iconic tiered clock tower.
e=find(284557568);cx,cz=pos(e);g=Group('jishi','积石堂 · 图书馆',(cx,cz),math.pi/2+.25,{'osm_id':e['id'],'photo':'校方招生网积石堂图文，2023-02-21','layout':'OSM; front axis matched to west entrance','height_status':'estimated'})
# The photo-led front is supplemented by the retrieved rear footprint.
angle=g.angle;g.angle=0;local=[(x-cx,z-cz) for x,z in points(e)];g.prism(local,12.5,'#d6d4c9',collision=True);g.facade(local,12.5,3);g.prism(local,.55,'#b7b8af',y=12.5);g.angle=angle
# Align the main front with the main campus avenue. Dimensions are a compact abstraction.
for x in (-27,27):g.building(x,24,32,23,14,'#d6d4c9',3)
# Recessed blue glazing and two stone piers, plus a shallow, broad arched lintel.
g.box(0,0,34,24,12.8,.7,'#385b68',True)
for x in (-13,13):g.box(x,0,36,3.5,13.5,5,'#d9d7ca',True)
g.box(0,13.5,36,29,4,5,'#d9d7ca');
for xx,char in zip([-8,0,8],'积石堂'):g.text(char,xx,14.3,38.6,2.8,'#46565d')
# Smaller actual entrance arch in front of the broad glazed arch.
for x in (-5.2,5.2):g.box(x,0,39,2.4,6.4,4,'#d4d1c2',True)
for i in range(18):
 a=i*math.pi/18;b=(i+1)*math.pi/18
 for z in (37,41.05):g.quad((4*math.cos(a),6.3+4*math.sin(a),z),(5.9*math.cos(a),6.3+5.9*math.sin(a),z),(5.9*math.cos(b),6.3+5.9*math.sin(b),z),(4*math.cos(b),6.3+4*math.sin(b),z),'#d4d1c2')
g.box(0,17.5,5,18,1.1,15,'#b8b8a9');g.box(0,18.6,5,10,10,9,'#b9b8a9')
for x in (-3.6,3.6):g.box(x,19,9.55,1.2,9,.2,'#3d5e5d')
g.box(0,28.6,5,13,.65,11,'#d0cdbc');g.box(0,29.25,5,5,6,5,'#bfbda8');g.box(0,35.25,5,1.7,3.8,1.7,'#c1bfaa');g.box(0,39,5,.15,4,.15,'#7f8b88')
# Clock face: square pale face with dark ticks and hands, not a fabricated school emblem.
g.box(0,24,9.62,4.4,4.4,.2,'#ecebdd')
for i in range(12):
 a=i*math.tau/12;g.box(math.sin(a)*1.65,26.2+math.cos(a)*1.65,9.8,.18,.35,.08,'#354d51')
g.box(-.45,26.1,9.88,1.25,.18,.10,'#354d51');g.box(0,26.1,9.89,.18,1.5,.10,'#354d51')
# Roof cornice and entrance steps.
for i in range(4):g.box(0,.22+i*.18,46-i*.8,39,.18,8-i*1.6,'#bfc1b4')
front=g.world((0,0,65));place(g,'积石堂','西区核心地标','依据校方白天照片制作钟楼、石色两翼、拱形入口和馆名；建筑尺寸与高度简化。',205,[front[0],front[2]])
places[-1]['h']=45
# West main gate: bridge form, gray stone pillars and gold university name.
plaza=xy(103.85646,36.04707);lib=(cx,cz);d=unit2=(plaza[0]-lib[0],plaza[1]-lib[1]);ll=math.hypot(*d);d=(d[0]/ll,d[1]/ll)
ray=LineString([plaza,(plaza[0]+d[0]*900,plaza[1]+d[1]*900)]);hit=ray.intersection(Polygon(boundaries[0]).boundary);hx,hz=hit.x,hit.y
gate=(hx-d[0]*9,hz-d[1]*9);theta=math.atan2(-d[0],d[1]);g=Group('cg_gate','城关西区正门',gate,theta,{'layout':'OSM main-axis/boundary intersection approximation','appearance':'official main gate photograph','dimensions':'estimated'})
for x,h in [(-18,14),(18,12.5)]:g.box(x,0,0,4.6,h,5,'#8e9894',True);g.box(x,h,0,5,.55,5.5,'#727e7c')
g.box(0,8.5,0,32,2.7,4.8,'#9ca59e');
for xx,char in zip([-10.5,-3.5,3.5,10.5],'兰州大学'):g.text(char,xx,11.4,2.48,3.3,'#c8aa57')
for y in (1,3,5,7):
 for x in (-18,18):g.box(x,y,2.56,4.7,.06,.03,'#75827f')
approach=(gate[0]-d[0]*22,gate[1]-d[1]*22);place(g,'城关西区正门','西区核心地标','校方照片参考的桥梁形校门、灰色石柱与金色校名；位置沿OSM主轴近似定位。',120,approach)
# Alumni square: respect its axis and keep the design restrained without inventing a statue.
g=Group('alumni_plaza','校友广场',plaza,extras={'layout':'OSM main-road roundel; official campus guide','surface':'simplified paving'})
g.cylinder(0,0,15,.09,'#c9c7b3',y=.20,segments=48);g.cylinder(0,0,7,.035,'#adad96',y=.29,segments=32)
for a in range(0,360,45):
 angle=math.radians(a)
 # radial joints represented with thin strips.
 x=math.sin(angle)*10;z=math.cos(angle)*10;g.box(x,.325,z,.16,.02,7,'#b8b9a6')
place(g,'校友广场','西区核心地标','沿主轴与积石堂、正门建立关系；广场铺装为简化设计。',150,[plaza[0]-25,plaza[1]+15])
# Motto stone: correct wording and restrained photo-based colonnade. Position is approximate.
motto=(plaza[0]-46,plaza[1]-52);g=Group('motto_stone','校训石',motto,theta,{'appearance':'official motto stone photo','layout':'near-square approximate placement; needs local verification'})
g.cylinder(0,0,5,.18,'#c5c3b0',y=.09);g.prism([(-1.6,-.65),(1.5,-.65),(1.8,.6),(.2,1.05),(-1.8,.4)],3.8,'#c8bfa1',y=.27,collision=True)
for x,text in [(.55,'自强不息'),(-.45,'独树一帜')]:
 for i,char in enumerate(text):g.text(char,x,2.9-i*.65,1.1,.52,'#a34e40')
for i in range(9):
 a=math.pi*.1+i*math.pi*.8/8;xx=math.cos(a)*8;zz=-5-math.sin(a)*4
 g.box(xx,0,zz,.45,3.5,.45,'#e4e0ce');g.box(xx,3.5,zz,2.2,.35,.8,'#e4e0ce')
place(g,'校训石','西区地标','参考校方照片保留浅色石体、红色“自强不息、独树一帜”和曲廊；具体位置待核准。',75,[motto[0]-12,motto[1]+10])
# Shaw Science building keeps its actual retrieved footprint.
e=find(292292097);cx,cz=pos(e);g=Group('shaw_science','逸夫科学馆',(cx,cz),extras={'osm_id':e['id'],'floors_source':'OSM five-level candidate','appearance':'simplified'})
p=[(x-cx,z-cz) for x,z in points(e)];g.prism(p,18,'#d9d5c7',collision=True);g.facade(p,18,5);g.prism(p,.6,'#aeb3a9',y=18);place(g,'逸夫科学馆','西区地标','保留OSM平面轮廓与五层体量候选；立面和高度简化。',150)
# Student activity centre: broad glazed podium and a taller pale tower.
e=find(511734229);cx,cz=pos(e);g=Group('student_center','大学生活动中心',(cx,cz),extras={'osm_id':e['id'],'appearance':'official student-centre photo','height_status':'estimate'})
p=[(x-cx,z-cz) for x,z in points(e)];g.prism(p,10.5,'#d3d4c8',collision=True);g.facade(p,10.5,3);g.prism(p,.6,'#a9b1ab',y=10.5);g.building(8,-3,36,22,34,'#d9d6c9',9);g.box(16,10.5,8.1,5,22,.2,'#4e7682');place(g,'大学生活动中心','西区核心地标','按官方照片保留玻璃基座、浅色高层和竖向玻璃带；位置来自OSM，尺度简化。',210)
# East campus major building: preserve the unusual multi-wing Xinglin footprint.
e=find(284759754);cx,cz=pos(e);g=Group('xinglin','杏林楼',(cx,cz),extras={'osm_id':e['id'],'height_m':25,'height_source':'OSM; not field checked','facade':'simplified, no verified multi-angle photo'})
p=[(x-cx,z-cz) for x,z in points(e)];g.prism(p,25,'#d8d5c6',collision=True);g.facade(p,25,7);g.prism(p,.65,'#afb3aa',y=25);
if area(p)<0:p.reverse()
a,b=max([(a,b) for a,b in zip(p,p[1:]+p[:1]) if math.dist(a,b)>12],key=lambda ab:(ab[0][1]+ab[1][1])/2)
ll=math.dist(a,b);nx=(b[1]-a[1])/ll;nz=-(b[0]-a[0])/ll;old_center=g.center
g.center=(cx+(a[0]+b[0])/2+nx*.16,cz+(a[1]+b[1])/2+nz*.16);g.angle=math.atan2(b[1]-a[1],b[0]-a[0])+math.pi
g.text('杏林楼',0,18.5,0,min(8,ll*.7));g.center=old_center;g.angle=0
place(g,'杏林楼','东区核心地标','保留OSM多翼平面轮廓与25米高度候选；名称已核对，立面暂作简化。',210,[cx-70,cz+20])
# Mark the east campus north entrance without borrowing the west gate architecture.
east_gate=xy(103.8629,36.04815);g=Group('east_gate','城关东区北门 · 体量示意',east_gate,math.pi,{'layout':'published east-campus guide','appearance':'placeholder, requires front photo'})
for x in (-12,12):g.box(x,0,0,2,3.4,3,'#a8ada1',True)
g.box(18,0,0,9,2.1,1.2,'#b9bbaa',True);g.text('兰州大学',18,.7,.68,7);place(g,'城关东区北门','东区入口','依据东区导览图安排入口；门体为简化体量，不替代现状照片。',105,[east_gate[0],east_gate[1]+18])
# OSM sports fields and simplified athletics tracks around the two main soccer pitches.
g=Group('sports_fields','城关田径场与球场');field_shapes=[]
for e in selected['pitches']:
 p=points(e);shape=Polygon(p);cx,cz=shape.centroid.x,shape.centroid.y;t=e['tags'];sport=t.get('sport');col='#6d9d84' if sport=='soccer' else '#809e90' if sport=='tennis' else '#b47c62';
 if not (sport=='soccer' and e['id'] in (284557571,284759362)):g.prism(p,.08,col,y=.26)
 field_shapes.append(shape)
 if sport=='soccer' and e['id'] in (284557571,284759362):
  # Rounded track follows the field's oriented bounding rectangle, with estimates for lanes.
  rect=list(shape.minimum_rotated_rectangle.exterior.coords)[:4];lengths=[math.dist(rect[i],rect[(i+1)%4]) for i in range(4)];axis=0 if lengths[0]>lengths[1] else 1;a,b=rect[axis],rect[(axis+1)%4];dx,dz=b[0]-a[0],b[1]-a[1];ll=math.hypot(dx,dz);long=ll;short=min(lengths);ux,uz=dx/ll,dz/ll;vx,vz=-uz,ux;rad=short*.5+5;straight=max(5,long*.5-rad+10)
  def stadium(r):
   out=[]
   for i in range(64):
    th=i*math.tau/64;u=(straight if math.cos(th)>0 else -straight)+r*math.cos(th);v=r*math.sin(th);out.append((cx+ux*u+vx*v,cz+uz*u+vz*v))
   return out
  outer=Polygon(stadium(rad+7));inner=Polygon(stadium(rad));sheet(g,outer.difference(inner),.28,'#b27058');sheet(g,inner,.30,'#739a78');field_shapes.append(outer)
  for n in range(1,5):sheet(g,Polygon(stadium(rad+n*1.35)).boundary.buffer(.07),.29,'#eee4ca')
  # Soccer markings remain inside the real retrieved pitch.
  minpx,minpz,maxpx,maxpz=shape.bounds
  half_long=straight+rad*.45;half_short=rad*.65
  pitch=[(cx+ux*u+vx*v,cz+uz*u+vz*v) for u,v in [(-half_long,-half_short),(half_long,-half_short),(half_long,half_short),(-half_long,half_short)]]
  g.prism(pitch,.04,'#80a68c',y=.31)
  for aa,bb in zip(pitch,pitch[1:]+pitch[:1]):sheet(g,LineString([aa,bb]).buffer(.12),.36,'#e7e7cd')
  sheet(g,LineString([(cx-vx*half_short,cz-vz*half_short),(cx+vx*half_short,cz+vz*half_short)]).buffer(.12),.36,'#e7e7cd')
  key='west_track' if e['id']==284557571 else 'east_track';name='西区田径场' if key=='west_track' else '东区田径场';places.append({'id':key,'name':name,'kind':'运动场','x':cx,'z':cz,'h':2,'distance':260,'note':'场地位置来自OSM；外圈跑道宽度与线条为估计。','approach':[cx+65,cz]})
# The guide marks a lake north of the main axis; its outline is a deliberate approximation.
g=Group('water','毓秀湖与小径 · 轮廓示意',extras={'source':'published west-campus guide','outline_status':'schematic; not surveyed'})
# Its approximate location is kept clear of the OSM library and science buildings.
lake_center=xy(103.85750,36.04768);lx,lz=lake_center
lake=[(lx+math.cos(i*math.tau/24)*(16+3*math.sin(i*.9)),lz+math.sin(i*math.tau/24)*36) for i in range(24)]
g.prism(lake,.035,'#729d9b',y=.11)
# Trees and lamps, avoiding building outlines, sports pitches and road clearances.
g=Group('trees','城关绿化');obstacles=[Polygon(c['polygon']) for c in colliders];treepts=[]
for _ in range(2400):
 x=random.uniform(minx,maxx);z=random.uniform(minz,maxz);point=Point(x,z)
 if not campus.covers(point) or any(s.distance(point)<4 for s in obstacles) or any(s.buffer(10).covers(point) for s in field_shapes) or Polygon(lake).buffer(4).covers(point):continue
 if any(segdist((x,z),a,b)<w*.78 for a,b,w in roadlines):continue
 if any(math.dist((x,z),q)<11 for q in treepts):continue
 treepts.append((x,z));plant(g,x,z,random.uniform(5,8.5),random.choice(['#618056','#77915f','#84966b','#929b6a']))
 if len(treepts)>=245:break
g=Group('lamps_benches','城关路灯与长椅')
for k,(a,b,w) in enumerate(roadlines):
 if w<6 or k%4:continue
 x=(a[0]+b[0])/2;z=(a[1]+b[1])/2+w*.8
 if not campus.covers(Point(x,z)) or any(s.distance(Point(x,z))<2 for s in obstacles):continue
 g.box(x,0,z,.22,4.6,.22,'#5d6c64');g.box(x+.6,4.5,z,1.3,.16,.45,'#7c897d');g.box(x+1,4.35,z,.55,.12,.6,'#dfd6ad')
# Store boundary provenance and a shared urban walking domain. The public connector is an approximate context strip.
walk_rect=[(minx-10,minz-10),(maxx+10,minz-10),(maxx+10,maxz+10),(minx-10,maxz+10)]
meta={'origin':ORIGIN,'boundary':walk_rect,'boundaries':boundaries,'walk_boundaries':[walk_rect],'view':{'target':[(minx+maxx)/2,0,(minz+maxz)/2],'distance':1750,'mini_width':1700,'yaw':-.65,'pitch':.88},'entry':list(approach),'aim':list(plaza),'stats':{'osm_building_candidates':len(buildings),'road_candidates':len(selected['roads']),'trees':len(treepts)},'source_snapshot_utc':raw['osm3s']['timestamp_osm_base'],'scope':'West and east in shared local geographic coordinates; urban context and connector simplified.'}
export_scene('chengguan',meta,['jishi','cg_gate','alumni_plaza','motto_stone','shaw_science','student_center','xinglin','east_gate'])
