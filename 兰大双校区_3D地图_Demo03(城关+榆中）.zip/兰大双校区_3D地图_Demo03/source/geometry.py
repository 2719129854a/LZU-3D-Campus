"""Rebuild the editable campus GLB and its self-contained offline viewer.
Python 3 + Pillow + Shapely >= 2.1. Coordinates: metres, +X east, +Y up, -Z north.
All architectural heights and terrain elevations are design estimates.
"""
import json, math, random, struct, base64, shutil, csv, os
from pathlib import Path
from array import array
from PIL import Image, ImageFont, ImageDraw
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; DIST=ROOT/'dist'; MODEL=ROOT/'models'
DIST.mkdir(exist_ok=True); MODEL.mkdir(exist_ok=True)
ORIGIN=(104.152,35.9435); COS=math.cos(math.radians(ORIGIN[1])); random.seed(1105)
def xy(lon,lat): return ((lon-ORIGIN[0])*111320*COS,(ORIGIN[1]-lat)*111320)
def polyof(f): return [xy(*p) for p in f['geometry']['coordinates'][0][:-1]]
def inside(p,poly):
 x,z=p;c=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[1]>z)!=(b[1]>z) and x<(b[0]-a[0])*(z-a[1])/(b[1]-a[1])+a[0]:c=not c
 return c
def segdist(p,a,b):
 x,z=p;dx=b[0]-a[0];dz=b[1]-a[1];t=max(0,min(1,((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz or 1)))
 return math.hypot(x-a[0]-t*dx,z-a[1]-t*dz)
def rgb(h):return [(int(h[i:i+2],16)/255)**2.2 for i in (1,3,5)]
def area(p):return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))/2

def triangulate(p):
 # Ear clipping; preserve the full concave footprint, do not fill courtyards.
 ids=list(range(len(p)))
 if area(p)<0:ids.reverse()
 out=[];guard=0
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 while len(ids)>3 and guard<len(p)**2:
  guard+=1;found=False
  for k in range(len(ids)):
   a,b,c=ids[k-1],ids[k],ids[(k+1)%len(ids)]
   if cross(p[a],p[b],p[c])<=1e-7:continue
   if any(cross(p[a],p[b],p[q])>1e-7 and cross(p[b],p[c],p[q])>1e-7 and cross(p[c],p[a],p[q])>1e-7 for q in ids if q not in (a,b,c)):continue
   out.append((a,b,c));ids.pop(k);found=True;break
  if not found:break
 if len(ids)==3:out.append(tuple(ids))
 expected=abs(area(p));actual=sum(abs(area([p[a],p[b],p[c]])) for a,b,c in out)
 if abs(actual-expected)>max(.01,expected*.0001):raise ValueError('Invalid roof triangulation')
 return out
nodes=[]; colliders=[]; places=[]; records=[]
class Group:
 def __init__(self,id,name,center=(0,0),angle=0,extras=None):
  self.id=id;self.name=name;self.center=center;self.angle=angle;self.p=[];self.n=[];self.c=[];self.extras=extras or {};nodes.append(self)
 def world(self,p):
  x,y,z=p;ca=math.cos(self.angle);sa=math.sin(self.angle);return (self.center[0]+ca*x-sa*z,y,self.center[1]+sa*x+ca*z)
 def tri(self,a,b,c,col):
  a,b,c=map(self.world,(a,b,c));u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)];n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];s=math.sqrt(sum(q*q for q in n)) or 1;n=[q/s for q in n];cc=rgb(col)
  for p in (a,b,c):self.p.extend(p);self.n.extend(n);self.c.extend(cc)
 def quad(self,a,b,c,d,col):self.tri(a,b,c,col);self.tri(a,c,d,col)
 def box(self,x,y,z,w,h,d,col,collision=False):
  v=[(x-w/2,y,z-d/2),(x+w/2,y,z-d/2),(x+w/2,y,z+d/2),(x-w/2,y,z+d/2),(x-w/2,y+h,z-d/2),(x+w/2,y+h,z-d/2),(x+w/2,y+h,z+d/2),(x-w/2,y+h,z+d/2)]
  for a,b,c,e in [(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)]:self.quad(v[a],v[b],v[c],v[e],col)
  if collision and y<2:colliders.append({'id':self.id,'polygon':[[self.world(p)[0],self.world(p)[2]] for p in v[:4]],'height':y+h})
 def prism(self,p,h,col,y=0,collision=False):
  p=list(p)
  if area(p)<0:p.reverse()
  for a,b,c in triangulate(p):self.tri((p[a][0],y+h,p[a][1]),(p[c][0],y+h,p[c][1]),(p[b][0],y+h,p[b][1]),col)
  for a,b in zip(p,p[1:]+p[:1]):self.quad((a[0],y,a[1]),(a[0],y+h,a[1]),(b[0],y+h,b[1]),(b[0],y,b[1]),col)
  if collision:colliders.append({'id':self.id,'polygon':[[self.world((x,0,z))[0],self.world((x,0,z))[2]] for x,z in p],'height':h})
 def cylinder(self,x,z,r,h,col,y=0,segments=16):self.prism([(x+math.cos(i*math.tau/segments)*r,z+math.sin(i*math.tau/segments)*r) for i in range(segments)],h,col,y)
 def building(self,x,z,w,d,h,col='#ded9c8',floors=5):
  self.box(x,0,z,w,h,d,col,True);self.box(x,h,z,w+.7,.6,d+.7,'#bab9ad')
  self.facade([(x-w/2,z-d/2),(x+w/2,z-d/2),(x+w/2,z+d/2),(x-w/2,z+d/2)],h,floors)
 def facade(self,p,h,floors):
  if area(p)<0:p=p[::-1]
  for a,b in zip(p,p[1:]+p[:1]):
   length=math.dist(a,b)
   if length<5:continue
   dx=(b[0]-a[0])/length;dz=(b[1]-a[1])/length;nx=dz*.06;nz=-dx*.06
   for j in range(floors):
    y=2.2+j*(h-2)/floors;wh=min(1.8,(h-2)/floors*.55)
    self.quad((a[0]+dx*1.2+nx,y,a[1]+dz*1.2+nz),(a[0]+dx*1.2+nx,y+wh,a[1]+dz*1.2+nz),(b[0]-dx*1.2+nx,y+wh,b[1]-dz*1.2+nz),(b[0]-dx*1.2+nx,y,b[1]-dz*1.2+nz),'#3c606b')
    # A few stone mullions, avoiding a mass of tiny window cubes.
    for t in range(6,int(length)-2,6):
     xx=a[0]+dx*t+nx*2;zz=a[1]+dz*t+nz*2
     self.quad((xx-dx*.18,y,zz-dz*.18),(xx-dx*.18,y+wh,zz-dz*.18),(xx+dx*.18,y+wh,zz+dz*.18),(xx+dx*.18,y,zz+dz*.18),'#e2ddcd')
 def text(self,text,x,y,z,width,col='#314a54'):
  # Extruded scanline lettering: remains geometry in GLB, with no web font dependency.
  font_path=os.environ.get('LZU_FONT_PATH') or next((str(q) for q in [Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'),Path('C:/Windows/Fonts/msyhbd.ttc')] if q.exists()),'NotoSansCJK-Bold.ttc')
  font=ImageFont.truetype(font_path,24)
  bb=font.getbbox(text);im=Image.new('L',(bb[2]+2,30));ImageDraw.Draw(im).text((0,-bb[1]),text,font=font,fill=255)
  im=im.crop(im.getbbox());s=width/im.width
  for yy in range(im.height):
   xx=0
   while xx<im.width:
    if im.getpixel((xx,yy))<120:xx+=1;continue
    end=xx+1
    while end<im.width and im.getpixel((end,yy))>=120:end+=1
    self.box(x-width/2+(xx+end)/2*s,y+(im.height-yy)*s,z,(end-xx)*s,s,.08,col);xx=end

def place(g,name,kind,note,view=150,approach=None):
 p={'id':g.id,'name':name,'kind':kind,'x':g.center[0],'z':g.center[1],'h':30,'distance':view,'note':note,'approach':approach or [g.center[0],g.center[1]+70]};places.append(p)


def plant(g,x,z,h,col):
 """Bounded visual update: an eight-sided crown and a subtle contact patch."""
 g.cylinder(x,z,3.3,.006,'#81976d',y=.101,segments=12)
 g.box(x,0,z,.55,h*.63,.55,'#7e6c54')
 rings=[(h*.36,2.0),(h*.65,3.1),(h*.94,2.0)]
 for j in range(len(rings)-1):
  y,r=rings[j];yy,rr=rings[j+1]
  for i in range(8):
   a=i*math.tau/8;b=(i+1)*math.tau/8
   g.quad((x+r*math.cos(a),y,z+r*math.sin(a)),(x+rr*math.cos(a),yy,z+rr*math.sin(a)),(x+rr*math.cos(b),yy,z+rr*math.sin(b)),(x+r*math.cos(b),y,z+r*math.sin(b)),col)
 y,r=rings[-1]
 for i in range(8):
  a=i*math.tau/8;b=(i+1)*math.tau/8
  g.tri((x,h*1.1,z),(x+r*math.cos(b),y,z+r*math.sin(b)),(x+r*math.cos(a),y,z+r*math.sin(a)),col)

def contact_shadows():
 from shapely.geometry import Polygon
 from shapely.ops import unary_union
 from shapely import constrained_delaunay_triangles
 ps=[Polygon(c['polygon']).buffer(2,join_style=2) for c in colliders if len(c['polygon'])>2]
 if not ps:return
 g=Group('contact_shadows','建筑接地阴影 · 风格化')
 for t in constrained_delaunay_triangles(unary_union(ps)).geoms:
  p=list(t.exterior.coords)[:3]
  if area(p)<0:p.reverse()
  g.tri((p[0][0],.105,p[0][1]),(p[2][0],.105,p[2][1]),(p[1][0],.105,p[1][1]),'#7f956d')

def export_scene(key,meta,core_ids):
 """Export shared-material, independently editable nodes and compact landmarks."""
 import hashlib
 contact_shadows()
 blob=bytearray();views=[];access=[];meshes=[];jnodes=[]
 def add(values,kind,mins=False):
  off=len(blob);data=array('f',values).tobytes();blob.extend(data);vi=len(views);views.append({'buffer':0,'byteOffset':off,'byteLength':len(data),'target':34962});ac={'bufferView':vi,'componentType':5126,'count':len(values)//3,'type':kind}
  if mins:ac.update(min=[min(values[i::3]) for i in range(3)],max=[max(values[i::3]) for i in range(3)])
  access.append(ac);return len(access)-1
 for g in nodes:
  if not g.p:continue
  lp=[v-(g.center[0] if i%3==0 else g.center[1] if i%3==2 else 0) for i,v in enumerate(g.p)]
  cols=g.c.copy()
  if g.id not in ('trees','terrain_campus','roads','sports_fields','water','context','contact_shadows','cuiying_mountain'):
   # Small amount of vertex-baked grounding; no new rendering dependency.
   for i in range(0,len(cols),3):
    ao=.88+.12*min(1,max(0,g.p[i+1])/13)
    for k in range(3):cols[i+k]*=ao
  pa=add(lp,'VEC3',True);na=add(g.n,'VEC3');ca=add(cols,'VEC3');meshes.append({'name':g.id,'primitives':[{'attributes':{'POSITION':pa,'NORMAL':na,'COLOR_0':ca},'material':0}]});jnodes.append({'name':g.id+' | '+g.name,'mesh':len(meshes)-1,'translation':[g.center[0],0,g.center[1]],'extras':dict(g.extras,stable_id=g.id)})
 title='兰州大学城关校区（西区与东区）' if key=='chengguan' else '兰州大学榆中校区'
 gltf={'asset':{'version':'2.0','generator':'LZU Dual Campus Demo03','copyright':'Geographic data © OpenStreetMap contributors, ODbL 1.0'},'scene':0,'scenes':[{'name':title,'nodes':list(range(len(jnodes)))}],'nodes':jnodes,'meshes':meshes,'materials':[{'name':'Campus matte vertex colours','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'metallicFactor':0,'roughnessFactor':.88},'doubleSided':True}],'accessors':access,'bufferViews':views,'buffers':[{'byteLength':len(blob)}],'extras':{'origin_wgs84':meta['origin'],'units':'metres','axes':'+X east; +Y up; -Z north','height_status':'OSM fields when consistent; otherwise estimates; not surveyed','date':'2026-11-06'}}
 def pack(j,b):
  j=json.dumps(j,ensure_ascii=False,separators=(',',':')).encode();j+=b' '*((-len(j))%4);b+=b'\0'*((-len(b))%4)
  return struct.pack('<III',0x46546c67,2,28+len(j)+len(b))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(b),0x004e4942)+b
 glb=pack(gltf,blob.copy());name=f'lzu_{key}_demo_v3.glb';(MODEL/name).write_bytes(glb)
 meta.update(version='03',campus_key=key,title=title,model_filename=name,core_ids=core_ids,colliders=colliders,places=places,model_sha256=hashlib.sha256(glb).hexdigest());meta['stats'].update(mesh_nodes=len(jnodes),triangles=sum(len(g.p)//9 for g in nodes));(DATA/key/'scene_metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
 for stable_id in core_ids:
  old_node=next(n for n in jnodes if n['extras']['stable_id']==stable_id);old_mesh=meshes[old_node['mesh']];sb=bytearray();sv=[];sa=[];attrs={}
  for an,ai in old_mesh['primitives'][0]['attributes'].items():
   ac=dict(access[ai]);bv=views[ac['bufferView']];off=len(sb);sb.extend(blob[bv['byteOffset']:bv['byteOffset']+bv['byteLength']]);sv.append({'buffer':0,'byteOffset':off,'byteLength':bv['byteLength'],'target':34962});ac['bufferView']=len(sv)-1;sa.append(ac);attrs[an]=len(sa)-1
  q={**gltf,'nodes':[{**old_node,'mesh':0,'translation':[0,0,0]}],'scenes':[{'nodes':[0],'name':old_node['name']}],'meshes':[{'name':stable_id,'primitives':[{'attributes':attrs,'material':0}]}],'accessors':sa,'bufferViews':sv,'buffers':[{'byteLength':len(sb)}]};(MODEL/'landmarks'/f'{key}_{stable_id}.glb').write_bytes(pack(q,sb))
 with (DATA/key/'模型对象清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['稳定ID','名称','X东向米','Z南向米','依据与估计说明'])
  for g in nodes:w.writerow([g.id,g.name,*g.center,json.dumps(g.extras,ensure_ascii=False)])
 print(key,json.dumps(meta['stats']),len(glb),flush=True)
