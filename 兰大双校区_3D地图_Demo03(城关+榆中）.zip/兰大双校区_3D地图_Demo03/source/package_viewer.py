from pathlib import Path
import json,base64
root=Path(__file__).resolve().parents[1]
objects={}
for key in ['chengguan','yuzhong']:
 meta=json.loads((root/'data'/key/'scene_metadata.json').read_text());glb=(root/'models'/meta['model_filename']).read_bytes();objects[key]={'meta':meta,'glb':base64.b64encode(glb).decode()}
s=(root/'source/viewer.html').read_text().replace('__CAMPUSES__',json.dumps(objects,ensure_ascii=False,separators=(',',':')))
(root/'dist/index.html').write_text(s);print('Combined offline HTML:',len(s.encode()))
