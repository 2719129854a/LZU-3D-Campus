"""Recreate the candidate selection from the saved OSM snapshot (no network needed)."""
from pathlib import Path
import json
from shapely.geometry import Polygon,LineString
p=Path(__file__).resolve().parents[1]/'data/chengguan';raw=json.loads((p/'osm_raw.json').read_text());es=raw['elements'];ids=[464538785,284557567];edges=[next(e for e in es if e['id']==i) for i in ids];areas=[Polygon([(q['lon'],q['lat']) for q in e['geometry']]) for e in edges]
result={'boundaries':edges,'buildings':[],'roads':[],'pitches':[]}
for e in es:
 g=e.get('geometry',[]);t=e.get('tags',{})
 if len(g)<2:continue
 q=[(p['lon'],p['lat']) for p in g]
 if 'building'in t and len(q)>3 and any(a.covers(Polygon(q).representative_point()) for a in areas):result['buildings'].append(e)
 if 'highway'in t and any(a.intersects(LineString(q)) for a in areas):result['roads'].append(e)
 if t.get('leisure')=='pitch' and len(q)>3 and any(a.covers(Polygon(q).representative_point()) for a in areas):result['pitches'].append(e)
(p/'selected.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print({k:len(v) for k,v in result.items()})
