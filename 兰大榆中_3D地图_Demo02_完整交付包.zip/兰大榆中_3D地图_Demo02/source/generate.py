"""Rebuild the editable campus GLB and its self-contained offline viewer.
Python 3 + Pillow + Shapely >= 2.1. Coordinates: metres, +X east, +Y up, -Z north.
All architectural heights and terrain elevations are design estimates.
"""
import json, math, random, struct, base64, shutil, csv, os
from pathlib import Path
from array import array
from PIL import Image, ImageFont, ImageDraw
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; DIST=ROOT/'dist'; MODEL=ROOT/'models'
DIST.mkdir(exist_ok=True); MODEL.mkdir(exist_ok=True)
ORIGIN=(104.152,35.9435); COS=math.cos(math.radians(ORIGIN[1])); random.seed(1105)
def xy(lon,lat): return ((lon-ORIGIN[0])*111320*COS,(ORIGIN[1]-lat)*111320)
def polyof(f): return [xy(*p) for p in f['geometry']['coordinates'][0][:-1]]
def inside(p,poly):
 x,z=p;c=False
 for a,b in zip(poly,poly[1:]+poly[:1]):
  if (a[1]>z)!=(b[1]>z) and x<(b[0]-a[0])*(z-a[1])/(b[1]-a[1])+a[0]:c=not c
 return c
def segdist(p,a,b):
 x,z=p;dx=b[0]-a[0];dz=b[1]-a[1];t=max(0,min(1,((x-a[0])*dx+(z-a[1])*dz)/(dx*dx+dz*dz or 1)))
 return math.hypot(x-a[0]-t*dx,z-a[1]-t*dz)
def rgb(h):return [(int(h[i:i+2],16)/255)**2.2 for i in (1,3,5)]
def area(p):return sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))/2

def triangulate(p):
 # Ear clipping; preserve the full concave footprint, do not fill courtyards.
 ids=list(range(len(p)))
 if area(p)<0:ids.reverse()
 out=[];guard=0
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 while len(ids)>3 and guard<len(p)**2:
  guard+=1;found=False
  for k in range(len(ids)):
   a,b,c=ids[k-1],ids[k],ids[(k+1)%len(ids)]
   if cross(p[a],p[b],p[c])<=1e-7:continue
   if any(cross(p[a],p[b],p[q])>1e-7 and cross(p[b],p[c],p[q])>1e-7 and cross(p[c],p[a],p[q])>1e-7 for q in ids if q not in (a,b,c)):continue
   out.append((a,b,c));ids.pop(k);found=True;break
  if not found:break
 if len(ids)==3:out.append(tuple(ids))
 expected=abs(area(p));actual=sum(abs(area([p[a],p[b],p[c]])) for a,b,c in out)
 if abs(actual-expected)>max(.01,expected*.0001):raise ValueError('Invalid roof triangulation')
 return out
nodes=[]; colliders=[]; places=[]; records=[]
class Group:
 def __init__(self,id,name,center=(0,0),angle=0,extras=None):
  self.id=id;self.name=name;self.center=center;self.angle=angle;self.p=[];self.n=[];self.c=[];self.extras=extras or {};nodes.append(self)
 def world(self,p):
  x,y,z=p;ca=math.cos(self.angle);sa=math.sin(self.angle);return (self.center[0]+ca*x-sa*z,y,self.center[1]+sa*x+ca*z)
 def tri(self,a,b,c,col):
  a,b,c=map(self.world,(a,b,c));u=[b[i]-a[i] for i in range(3)];v=[c[i]-a[i] for i in range(3)];n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];s=math.sqrt(sum(q*q for q in n)) or 1;n=[q/s for q in n];cc=rgb(col)
  for p in (a,b,c):self.p.extend(p);self.n.extend(n);self.c.extend(cc)
 def quad(self,a,b,c,d,col):self.tri(a,b,c,col);self.tri(a,c,d,col)
 def box(self,x,y,z,w,h,d,col,collision=False):
  v=[(x-w/2,y,z-d/2),(x+w/2,y,z-d/2),(x+w/2,y,z+d/2),(x-w/2,y,z+d/2),(x-w/2,y+h,z-d/2),(x+w/2,y+h,z-d/2),(x+w/2,y+h,z+d/2),(x-w/2,y+h,z+d/2)]
  for a,b,c,e in [(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)]:self.quad(v[a],v[b],v[c],v[e],col)
  if collision and y<2:colliders.append({'id':self.id,'polygon':[[self.world(p)[0],self.world(p)[2]] for p in v[:4]],'height':y+h})
 def prism(self,p,h,col,y=0,collision=False):
  p=list(p)
  if area(p)<0:p.reverse()
  for a,b,c in triangulate(p):self.tri((p[a][0],y+h,p[a][1]),(p[c][0],y+h,p[c][1]),(p[b][0],y+h,p[b][1]),col)
  for a,b in zip(p,p[1:]+p[:1]):self.quad((a[0],y,a[1]),(a[0],y+h,a[1]),(b[0],y+h,b[1]),(b[0],y,b[1]),col)
  if collision:colliders.append({'id':self.id,'polygon':[[self.world((x,0,z))[0],self.world((x,0,z))[2]] for x,z in p],'height':h})
 def cylinder(self,x,z,r,h,col,y=0,segments=16):self.prism([(x+math.cos(i*math.tau/segments)*r,z+math.sin(i*math.tau/segments)*r) for i in range(segments)],h,col,y)
 def building(self,x,z,w,d,h,col='#ded9c8',floors=5):
  self.box(x,0,z,w,h,d,col,True);self.box(x,h,z,w+.7,.6,d+.7,'#bab9ad')
  self.facade([(x-w/2,z-d/2),(x+w/2,z-d/2),(x+w/2,z+d/2),(x-w/2,z+d/2)],h,floors)
 def facade(self,p,h,floors):
  if area(p)<0:p=p[::-1]
  for a,b in zip(p,p[1:]+p[:1]):
   length=math.dist(a,b)
   if length<5:continue
   dx=(b[0]-a[0])/length;dz=(b[1]-a[1])/length;nx=dz*.06;nz=-dx*.06
   for j in range(floors):
    y=2.2+j*(h-2)/floors;wh=min(1.8,(h-2)/floors*.55)
    self.quad((a[0]+dx*1.2+nx,y,a[1]+dz*1.2+nz),(a[0]+dx*1.2+nx,y+wh,a[1]+dz*1.2+nz),(b[0]-dx*1.2+nx,y+wh,b[1]-dz*1.2+nz),(b[0]-dx*1.2+nx,y,b[1]-dz*1.2+nz),'#3c606b')
    # A few stone mullions, avoiding a mass of tiny window cubes.
    for t in range(6,int(length)-2,6):
     xx=a[0]+dx*t+nx*2;zz=a[1]+dz*t+nz*2
     self.quad((xx-dx*.18,y,zz-dz*.18),(xx-dx*.18,y+wh,zz-dz*.18),(xx+dx*.18,y+wh,zz+dz*.18),(xx+dx*.18,y,zz+dz*.18),'#e2ddcd')
 def text(self,text,x,y,z,width,col='#314a54'):
  # Extruded scanline lettering: remains geometry in GLB, with no web font dependency.
  font_path=os.environ.get('LZU_FONT_PATH') or next((str(q) for q in [Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc'),Path('C:/Windows/Fonts/msyhbd.ttc')] if q.exists()),'NotoSansCJK-Bold.ttc')
  font=ImageFont.truetype(font_path,24)
  bb=font.getbbox(text);im=Image.new('L',(bb[2]+2,30));ImageDraw.Draw(im).text((0,-bb[1]),text,font=font,fill=255)
  im=im.crop(im.getbbox());s=width/im.width
  for yy in range(im.height):
   xx=0
   while xx<im.width:
    if im.getpixel((xx,yy))<120:xx+=1;continue
    end=xx+1
    while end<im.width and im.getpixel((end,yy))>=120:end+=1
    self.box(x-width/2+(xx+end)/2*s,y+(im.height-yy)*s,z,(end-xx)*s,s,.08,col);xx=end

def place(g,name,kind,note,view=150,approach=None):
 p={'id':g.id,'name':name,'kind':kind,'x':g.center[0],'z':g.center[1],'h':30,'distance':view,'note':note,'approach':approach or [g.center[0],g.center[1]+70]};places.append(p)

bfeatures=json.loads((DATA/'building_candidates.geojson').read_text())['features'];rfeatures=json.loads((DATA/'road_candidates.geojson').read_text())['features'];boundary=polyof(json.loads((DATA/'campus_boundary.geojson').read_text())['features'][0]);raw=json.loads((DATA/'osm_yuzhong_raw.json').read_text())
# Land base follows the actual retrieved university boundary.
g=Group('terrain_campus','校园地面',extras={'source':'OSM way 464554875','elevation':'design estimate'})
g.prism([(-1480,-650),(1020,-650),(1020,625),(-1480,625)],17.6,'#a8ae88',y=-18)
g.prism(boundary,9,'#b5bb91',y=-9);g.prism(boundary,.1,'#96ab79',y=-.02)
# Thin segmented outer rim.
for a,b in zip(boundary,boundary[1:]+boundary[:1]):
 dx=b[0]-a[0];dz=b[1]-a[1];l=math.hypot(dx,dz)
 if l>0:
  nx=dz/l*1.2;nz=-dx/l*1.2;g.quad((a[0],.2,a[1]),(b[0],.2,b[1]),(b[0]+nx,.2,b[1]+nz),(a[0]+nx,.2,a[1]+nz),'#d1c8a5')
# Stylized, deliberately approximate Cuiying Mountain on the west side.
g=Group('cuiying_mountain','萃英山 · 简化山体',extras={'elevation':'artistic approximation; not DEM'})
xs=[-1290,-1180,-1080,-990,-900,-820,-740];zs=list(range(-650,501,85));grid={}
for i,x in enumerate(xs):
 for j,z in enumerate(zs):
  base=max(0,1-abs(i-2.2)/4.3);ht=base*(185+55*math.sin(z/170)) if i<5 else max(0,(6-i)*22)
  hits=[]
  for a,b in zip(boundary,boundary[1:]+boundary[:1]):
   if (a[1]>z)!=(b[1]>z):hits.append(a[0]+(b[0]-a[0])*(z-a[1])/(b[1]-a[1]))
  edge=min(hits) if hits else -1000
  xx=-990-[420,330,250,175,110,50,4][i]
  grid[i,j]=(xx,round(max(0,ht+random.uniform(-8,8)) if i<6 else 0,1),z)
for i in range(len(xs)-1):
 for j in range(len(zs)-1):
  a,b,c,d=grid[i,j],grid[i+1,j],grid[i+1,j+1],grid[i,j+1]
  # Mountain must not overwrite the campus plateau.
  col=random.choice(['#a6a37b','#98996e','#b9b28b','#8e9d72'])
  g.tri(a,d,b,col);g.tri(d,c,b,col)
# Clipped road strips: no off-campus network accidentally included.
roadlines=[];g=Group('roads','校园道路与步道')
for f in rfeatures:
 p=[xy(*q) for q in f['geometry']['coordinates']];tag=f['properties'];typ=tag.get('highway','service');w=3.1 if typ in ('footway','path','steps') else 7 if typ=='service' else 10
 line=[]
 for a,b in zip(p,p[1:]):
  n=max(1,math.ceil(math.dist(a,b)/6))
  for k in range(n):
   aa=(a[0]+(b[0]-a[0])*k/n,a[1]+(b[1]-a[1])*k/n);bb=(a[0]+(b[0]-a[0])*(k+1)/n,a[1]+(b[1]-a[1])*(k+1)/n)
   mid=((aa[0]+bb[0])/2,(aa[1]+bb[1])/2)
   if not inside(mid,boundary):continue
   dx=bb[0]-aa[0];dz=bb[1]-aa[1];l=math.hypot(dx,dz)
   if l<.01:continue
   nx=dz/l*w/2;nz=-dx/l*w/2
   for width,y,col in [(1.45,.18,'#d4d0bb'),(1,.22,'#7f8b88' if w>4 else '#c2baa3')]:
    g.quad((aa[0]+nx*width,y,aa[1]+nz*width),(aa[0]-nx*width,y,aa[1]-nz*width),(bb[0]-nx*width,y,bb[1]-nz*width),(bb[0]+nx*width,y,bb[1]+nz*width),col)
   roadlines.append([aa,bb,w])
# Union the road surfaces before triangulation, eliminating duplicate coplanar
# faces at intersections in GLB/Blender as well as in the browser viewer.
from shapely.geometry import Polygon, LineString
from shapely.ops import unary_union
from shapely import constrained_delaunay_triangles
campus_shape=Polygon(boundary)
g.p.clear();g.n.clear();g.c.clear()
outer=unary_union([LineString([a,b]).buffer(w*.725,cap_style=2) for a,b,w in roadlines]).intersection(campus_shape)
asphalt=unary_union([LineString([a,b]).buffer(w*.5,cap_style=2) for a,b,w in roadlines if w>4]).intersection(campus_shape)
paths=unary_union([LineString([a,b]).buffer(w*.5,cap_style=2) for a,b,w in roadlines if w<=4]).intersection(campus_shape).difference(asphalt)
for surface,y,col in [(outer,.13,'#d4d0bb'),(asphalt,.18,'#7f8b88'),(paths,.19,'#c2baa3')]:
 for t in constrained_delaunay_triangles(surface).geoms:
  v=list(t.exterior.coords)[:3]
  if area(v)<0:v.reverse()
  g.tri((v[0][0],y,v[0][1]),(v[2][0],y,v[2][1]),(v[1][0],y,v[1][1]),col)

# Existing candidate footprint buildings; key sites are replaced by individual detail models.
skip={232146076,232146068,232146104,232146083}
for f in bfeatures:
 props=f['properties'];oid=props['osm_id']
 if oid in skip:continue
 p=polyof(f);cx=sum(x for x,z in p)/len(p);cz=sum(z for x,z in p)/len(p);name=props.get('name',f'校园建筑 {oid}');local=[(x-cx,z-cz) for x,z in p]
 dorm=('学' in name and not any(s in name for s in ['教学','学术','大学'])) or '公寓' in name
 h=19.5 if dorm else 15.5;floors=6 if dorm else 4;col='#d8c3a9' if dorm else '#dcdccf'
 if '餐' in name or '苑'in name:h=10;floors=3;col='#d6bc93'
 if name=='游泳馆':h=12;floors=2;col='#c6d4cb'
 gg=Group('osm_'+str(oid),name,(cx,cz),extras={'osm_id':oid,'height_m':h,'height_status':'estimated','layout':'OSM footprint'})
 gg.prism(local,h,col,collision=True);gg.facade(local,h,floors);gg.prism(local,.5,'#aaa89b',y=h)
 records.append({'id':gg.id,'name':name,'x':round(cx,2),'z':round(cz,2),'height':h,'layout':'OSM','appearance':'generic estimate'})
 if name in ('游泳馆','闻韶楼','闻欣堂','芝兰苑','玉树苑'):place(gg,name,'生活与公共空间','OSM 平面轮廓；立面与高度简化。',180)
# Kunlun Library: east-facing portal, two wings, recessed glazed entry and back court.
g=Group('kunlun','昆仑堂 · 图书馆',(-24,117),-math.pi/2,{'layout':'approximate registration of official guide; absent from retrieved OSM footprints','appearance':'official photo S03','height_m':29,'height_status':'estimated'})
for x in (-34,34):g.building(x,6,33,68,28,'#e3dfce',6)
g.building(0,-23,36,22,26,'#dedbca',6);g.box(0,22,31,36,7,19,'#e4e0d2');g.box(0,12,23,34,3.8,1,'#e5e1d3');g.text('昆 仑 堂',0,13,23.6,23)
g.box(0,0,13,24,11,2,'#345a69',True)
for x in (-11,-3.7,3.7,11):g.box(x,0,15,.7,11,3,'#dedcca')
for i in range(4):g.box(0,i*.32,44-i*1.1,52,.32,11-i*2.2,'#c9c8b9')
# Portal top vertical fins.
for x in range(-14,16,3):g.box(x,24,40.6,.45,3,.2,'#405967')
place(g,'昆仑堂','核心地标','中央大开口、东西向入口、两翼与水平窗带；外形依据官方照片，位置按导示图配准。',185,[60,117])
# Tianshan: retain actual concave OSM footprint, add pale six-floor facade and dark central entrance.
f=next(f for f in bfeatures if f['properties']['osm_id']==232146076);p=polyof(f);cx=sum(x for x,z in p)/len(p);cz=sum(z for x,z in p)/len(p)
g=Group('tianshan','天山堂',(cx,cz),extras={'osm_id':232146076,'height_m':25,'floors':6,'source':'S04/S04b','height_status':'estimated'})
local=[(x-cx,z-cz) for x,z in p];g.prism(local,25,'#e6e5da',collision=True);g.facade(local,25,6);g.prism(local,.6,'#b9bcb1',y=25)
minz,maxz=min(z for x,z in local),max(z for x,z in local);g.box(0,1,maxz+.25,17,21,.4,'#3d515d');g.text('天 山 堂',0,17,maxz+.6,13,'#d5bf87');g.box(0,4,maxz+4,22,.7,8,'#c2c8bf')
for x in (-8,8):g.box(x,0,maxz+5,.55,4,1,'#dddcd2')
place(g,'天山堂','核心地标','OSM 实际轮廓；六层浅色立面、中央深色入口与教学组团。',225,[cx,max(z for x,z in p)+30])
# Helan: both retrieved wings belong to the editable landmark node.
fs=[f for f in bfeatures if f['properties']['osm_id'] in (232146068,232146104)];ps=[polyof(f) for f in fs];cx=sum(x for p in ps for x,z in p)/sum(map(len,ps));cz=sum(z for p in ps for x,z in p)/sum(map(len,ps))
g=Group('helan','贺兰堂',(cx,cz),extras={'osm_ids':[232146068,232146104],'appearance':'official photo S05','height_m':24,'height_status':'estimated'})
for p in ps:
 local=[(x-cx,z-cz) for x,z in p];g.prism(local,24,'#d9ddda',collision=True);g.facade(local,24,6);g.prism(local,.45,'#b0b8b0',y=24)
maxz=max(z for p in ps for x,z in p)-cz;g.text('贺 兰 堂',0,18,maxz+.15,14);g.box(0,3.8,maxz+3,17,.6,7,'#c2cfc8')
place(g,'贺兰堂','核心地标','保留 OSM 两翼轮廓；浅灰立面、转角体量与入口雨棚。',200,[cx,maxz+cz+25])
# Museum: geometry source verified; external details deliberately restrained pending photo review.
f=next(f for f in bfeatures if f['properties']['osm_id']==232146083);p=polyof(f);cx=sum(x for x,z in p)/len(p);cz=sum(z for x,z in p)/len(p)
g=Group('museum','兰州大学校史馆博物馆',(cx,cz),extras={'osm_id':232146083,'height_m':12,'height_status':'estimated','appearance_status':'massing and partial north facade based on official ZSB photo; other sides pending review'})
local=[(x-cx,z-cz) for x,z in p];g.prism(local,12,'#e1dfd2',collision=True);g.prism(local,.65,'#bbb7a6',y=12)
# The official photograph shows a broad pale wall, not repetitive office windows.
a,b=max(zip(p,p[1:]+p[:1]),key=lambda ab:math.dist(*ab));mx=(a[0]+b[0])/2;mz=(a[1]+b[1])/2
old_center=g.center;g.center=(mx,mz);g.angle=math.atan2(b[1]-a[1],b[0]-a[0]);g.text('兰州大学博物馆',0,7,.2,27);g.center=old_center;g.angle=0
place(g,'校史馆博物馆','核心地标','OSM 展开式轮廓；浅色实体墙与馆名参考校方照片，其余立面仍需复核。',150,[cx+50,cz+20])
# Entrance and ethnic column: conceptual placeholders, explicitly identified in the model metadata.
g=Group('gate_main','榆中校区正门 · 体量占位',(912,124),math.pi/2,{'layout':'east entrance from official guide and OSM road','appearance_status':'conceptual placeholder; photo required'})
for x in (-23,23):g.box(x,0,0,4,5,5,'#c7baa1',True)
g.box(33,0,0,16,3,2,'#c8baa2',True);g.text('兰州大学',33,1.2,1.15,13)
# Open central roadway, low side railings.
for x in (-34,34):g.box(x,0,1,13,1.4,.35,'#476061')
place(g,'榆中校区正门','入口','已按东侧正门安排位置；门体暂为体量占位，待正面照片替换。',115,[875,124])
g=Group('ethnic_column','民族柱与入口广场 · 示意',(205,117),extras={'layout':'official guide plaza','appearance_status':'conceptual placeholder; close-up photo required'})
g.cylinder(0,0,26,.22,'#c9c4af');g.cylinder(0,0,6.5,.7,'#c2b9a0',y=.22);g.cylinder(0,0,3,1.2,'#b4a78b',y=.92);g.cylinder(0,0,1.7,16,'#b59f79',y=2.12,segments=12)
for y in (3,5,8,11,14,17):g.cylinder(0,0,1.9,.3,'#cabb91',y=y,segments=12)
g.cylinder(0,0,2.8,1,'#d7c69c',y=18,segments=12)
colliders.append({'id':g.id,'polygon':[[-3+205,-3+117],[3+205,-3+117],[3+205,3+117],[-3+205,3+117]],'height':20})
place(g,'民族柱广场','核心地标','广场关系来自官方导示图；柱体装饰暂为示意，等待近景照片校正。',125,[205,154])
# Athletics grounds from OSM shapes, not invented placement.
g=Group('sports_fields','田径场与球场')
for e in raw['elements']:
 if e.get('tags',{}).get('leisure')!='pitch' or not e.get('geometry'):continue
 p=[xy(q['lon'],q['lat']) for q in e['geometry'][:-1]]
 if not p or not inside((sum(x for x,z in p)/len(p),sum(z for x,z in p)/len(p)),boundary):continue
 name=e['tags'].get('name','球场');cx=sum(x for x,z in p)/len(p);cz=sum(z for x,z in p)/len(p)
 if '田径'in name:
  minx,maxx=min(x for x,z in p),max(x for x,z in p);minz,maxz=min(z for x,z in p),max(z for x,z in p);rx=(maxx-minx)/2;rz=(maxz-minz)/2;cx=(maxx+minx)/2;cz=(maxz+minz)/2
  def oval(rx,rz):
   straight=max(0,rz-rx);return [(cx+rx*math.cos(t),cz+(straight if math.sin(t)>0 else -straight)+rx*math.sin(t)) for t in [i*math.tau/80 for i in range(80)]]
  g.prism(oval(rx,rz),.18,'#b8755c',y=.3)
  for n in range(1,6):
   line=oval(rx-n*1.35,rz-n*1.35)
   for a,b in zip(line,line[1:]+line[:1]):
    dx=b[0]-a[0];dz=b[1]-a[1];l=math.hypot(dx,dz);nx=dz/l*.1;nz=-dx/l*.1;g.quad((a[0]+nx,.5,a[1]+nz),(b[0]+nx,.5,b[1]+nz),(b[0]-nx,.5,b[1]-nz),(a[0]-nx,.5,a[1]-nz),'#e8d9bc')
  g.prism(oval(rx-10,rz-10),.22,'#6e9976',y=.45)
  fw=(rx-13)*2;fl=rz*1.45;g.box(cx,.7,cz,fw,.05,fl,'#87aa7c')
  for xx in (-fw/2,fw/2):g.box(cx+xx,.76,cz,.25,.04,fl,'#eee7cf')
  for zz in (-fl/2,0,fl/2):g.box(cx,.76,cz+zz,fw,.04,.25,'#eee7cf')
  places.append({'id':'sports_'+str(e['id']),'name':name,'kind':'运动场','x':cx,'z':cz,'h':2,'distance':310,'note':'OSM 场地位置；跑道、球场线条简化。','approach':[cx+rx+20,cz]})
 else:
  g.prism(p,.15,'#759690' if e['tags'].get('sport')=='basketball' else '#8ca482',y=.3)
# Approximate new science group at west mountain foot; keep explicit provenance.
g=Group('shulihe','数理核学组团 · 位置示意',(-645,120),extras={'layout':'approximate west-side placement, requires survey','appearance':'official 2025 photograph S06','height_status':'estimated'})
g.building(0,0,112,28,24,'#c5ceca',6);g.box(0,3,14.15,106,20,.25,'#364a56');g.box(-37,0,16,5,28,4,'#994d3d',True)
for x in (-42,0,42):g.building(x,-31,21,35,21,'#e0e0d3',5)
for x in range(-49,52,4):g.box(x,3,14.5,.4,20,.2,'#8faaa8')
place(g,'数理核学组团','新增建筑','外形按 2025 年官方照片简化；西侧位置为示意，需以新底图核校。',205,[-645,180])
# Landscaping uses reproducible procedural placement, avoiding buildings and roads.
g=Group('trees','树木与绿化');treepts=[]
obstacles=[c['polygon'] for c in colliders]
for _ in range(1500):
 x=random.uniform(-800,900);z=random.uniform(-500,540)
 if not inside((x,z),boundary) or any(inside((x,z),p) or min(segdist((x,z),a,b) for a,b in zip(p,p[1:]+p[:1]))<6 for p in obstacles):continue
 if any(segdist((x,z),a,b)<w*.8 for a,b,w in roadlines):continue
 if any(math.dist((x,z),q)<15 for q in treepts):continue
 if any('田径'in p['name'] and ((x-p['x'])/72)**2+((z-p['z'])/122)**2<1.25 for p in places):continue
 treepts.append((x,z));h=random.uniform(5,9);c=random.choice(['#64815c','#799263','#8c9b66','#a8a36c'])
 g.box(x,0,z,.8,h*.6,.8,'#82715b');g.box(x,h*.36,z,5,h*.55,5,c);g.box(x,h*.76,z,3.8,h*.38,3.8,c)
 if len(treepts)>=330:break
# Lamp rows on a subset of longer primary road segments.
g=Group('lamps_benches','路灯与休憩设施')
for k,(a,b,w) in enumerate(roadlines):
 if w<7 or k%15:continue
 x=(a[0]+b[0])/2;z=(a[1]+b[1])/2+w*.95
 if any(inside((x,z),p) for p in obstacles):continue
 g.box(x,0,z,.35,5,.35,'#5f6e68');g.box(x+.8,4.8,z,1.7,.18,.5,'#536760');g.box(x+1.3,4.6,z,.7,.15,.7,'#e5d5a3')
for x,z in [(90,150),(120,150),(175,154),(235,154),(75,97)]:
 g.box(x,.6,z,4,.25,1.2,'#a1845c');g.box(x,1,z+.5,4,.9,.15,'#a1845c')
 for xx in (-1.4,1.4):g.box(x+xx,0,z,.18,.65,.7,'#5d7065')
# Export independent nodes to one GLB with shared flat vertex-colour material.
blob=bytearray();views=[];access=[];meshes=[];jnodes=[]
def add_accessor(values,kind,mins=False):
 while len(blob)%4:blob.append(0)
 off=len(blob);a=array('f',values);data=a.tobytes();blob.extend(data);vi=len(views);views.append({'buffer':0,'byteOffset':off,'byteLength':len(data),'target':34962});n=3 if kind=='VEC3' else 1
 ac={'bufferView':vi,'componentType':5126,'count':len(values)//n,'type':kind}
 if mins:ac.update(min=[min(values[i::n]) for i in range(n)],max=[max(values[i::n]) for i in range(n)])
 access.append(ac);return len(access)-1
for g in nodes:
 if not g.p:continue
 # An object pivot at its footprint centre makes subsequent editing practical.
 lp=[v-(g.center[0] if i%3==0 else g.center[1] if i%3==2 else 0) for i,v in enumerate(g.p)]
 pos=add_accessor(lp,'VEC3',True);nor=add_accessor(g.n,'VEC3');col=add_accessor(g.c,'VEC3')
 meshes.append({'name':g.id,'primitives':[{'attributes':{'POSITION':pos,'NORMAL':nor,'COLOR_0':col},'material':0}]})
 jnodes.append({'name':g.id+' | '+g.name,'mesh':len(meshes)-1,'translation':[g.center[0],0,g.center[1]],'extras':dict(g.extras,stable_id=g.id)})
gltf={'asset':{'version':'2.0','generator':'LZU Campus v2 procedural modeller','copyright':'Original geometry; geographic data © OpenStreetMap contributors ODbL 1.0'},'scene':0,'scenes':[{'name':'兰州大学榆中校区 · Demo 02','nodes':list(range(len(jnodes)))}],'nodes':jnodes,'meshes':meshes,'materials':[{'name':'Vertex colours','pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'metallicFactor':0,'roughnessFactor':1},'doubleSided':True}],'accessors':access,'bufferViews':views,'buffers':[{'byteLength':len(blob)}],'extras':{'origin_wgs84':[ORIGIN[0],ORIGIN[1]],'units':'metres','axes':'+X east, +Y up, -Z north','heights':'all estimated; not a survey product','date':'2026-11-05'}}
j=json.dumps(gltf,ensure_ascii=False,separators=(',',':')).encode();j+=b' '*((-len(j))%4);blob+=b'\0'*((-len(blob))%4)
glb=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob
model=MODEL/'lzu_yuzhong_demo_v2.glb';model.write_bytes(glb)
meta={'version':'02','origin':ORIGIN,'boundary':boundary,'colliders':colliders,'places':places,'stats':{'osm_building_candidates':len(bfeatures),'road_candidates':len(rfeatures),'mesh_nodes':len(jnodes),'triangles':sum(len(g.p)//9 for g in nodes),'trees':len(treepts)},'model_sha256':__import__('hashlib').sha256(glb).hexdigest()}
(DATA/'scene_metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
for p in places:
 records.append({'id':p['id'],'name':p['name'],'x':round(p['x'],2),'z':round(p['z'],2),'height':'estimated','layout':'see note','appearance':p['note']})
with (ROOT/'模型对象清单.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['id','name','x','z','height','layout','appearance']);w.writeheader();w.writerows(records)
html=(ROOT/'source/viewer.html').read_text().replace('__META__',json.dumps(meta,ensure_ascii=False,separators=(',',':'))).replace('__GLB__',base64.b64encode(glb).decode())
(DIST/'index.html').write_text(html);print(json.dumps(meta['stats'],ensure_ascii=False));print('GLB',len(glb),'HTML',len(html.encode()))
# Compact, independent exports for each core object.
landmark_dir=MODEL/'landmarks';landmark_dir.mkdir(exist_ok=True)
for stable_id in ['kunlun','tianshan','helan','museum','gate_main','ethnic_column','shulihe']:
 ni=next(i for i,n in enumerate(jnodes) if n['extras']['stable_id']==stable_id);old_node=jnodes[ni];old_mesh=meshes[old_node['mesh']];attrs=old_mesh['primitives'][0]['attributes'];sb=bytearray();sv=[];sa=[];new_attrs={}
 for name,ai in attrs.items():
  ac=dict(access[ai]);bv=views[ac['bufferView']];off=len(sb);sb.extend(blob[bv['byteOffset']:bv['byteOffset']+bv['byteLength']]);sv.append({'buffer':0,'byteOffset':off,'byteLength':bv['byteLength'],'target':34962});ac['bufferView']=len(sv)-1;sa.append(ac);new_attrs[name]=len(sa)-1
 single={**gltf,'nodes':[{**old_node,'mesh':0,'translation':[0,0,0]}],'scenes':[{'nodes':[0],'name':old_node['name']}],'meshes':[{'name':stable_id,'primitives':[{'attributes':new_attrs,'material':0}]}],'accessors':sa,'bufferViews':sv,'buffers':[{'byteLength':len(sb)}]}
 jj=json.dumps(single,ensure_ascii=False,separators=(',',':')).encode();jj+=b' '*((-len(jj))%4);sb+=b'\0'*((-len(sb))%4);out=struct.pack('<III',0x46546c67,2,28+len(jj)+len(sb))+struct.pack('<II',len(jj),0x4e4f534a)+jj+struct.pack('<II',len(sb),0x004e4942)+sb
 (landmark_dir/(stable_id+'.glb')).write_bytes(out)
