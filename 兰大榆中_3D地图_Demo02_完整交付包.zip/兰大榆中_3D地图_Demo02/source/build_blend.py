"""Run with blender --background --python source/build_blend.py."""
import bpy, math, json
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.gltf(filepath=str(root/'models/lzu_yuzhong_demo_v2.glb'))
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
# Keep the actual GLB imported meshes, pivots, vertex colours and object metadata.
mesh_objects=[o for o in scene.objects if o.type=='MESH']
for o in mesh_objects:
 if o.data.color_attributes:
  o.data.color_attributes.active_color=o.data.color_attributes[0]
scene.world=bpy.data.worlds.new('Campus daylight');scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.69,.79,.80,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
bpy.ops.object.light_add(type='AREA',location=(-600,-450,1200));light=bpy.context.object;light.name='Daylight area';light.data.energy=11000000;light.data.shape='DISK';light.data.size=900
bpy.ops.object.camera_add();camera=bpy.context.object;scene.camera=camera;camera.name='校园全景';camera.data.type='ORTHO';camera.data.ortho_scale=2700;camera.data.clip_end=10000
camera.location=(1050,-1450,1350);target=Vector((-190,0,0));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=32;scene.cycles.use_denoising=False
scene.render.resolution_x=1600;scene.render.resolution_y=1050;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast' if 'Medium High Contrast' in [i.identifier for i in scene.bl_rna.properties['view_settings'].fixed_type.properties['look'].enum_items] else 'None'
scene['notes']='Demo geometry. All building heights and terrain are estimated. Gate/column appearance and science-group placement are placeholders. Geographic data: © OpenStreetMap contributors, ODbL 1.0.'
# Imported scene remains fully editable; camera and lighting are separate objects.
bpy.ops.wm.save_as_mainfile(filepath=str(root/'models/lzu_yuzhong_demo_v2.blend'))
scene.render.filepath=str(root/'reviews/campus_overview.png');bpy.ops.render.render(write_still=True)
camera.name='昆仑堂近景';camera.data.ortho_scale=170;camera.location=(120,-5,78);target=Vector((-24,-117,12));camera.rotation_euler=(target-camera.location).to_track_quat('-Z','Y').to_euler()
scene.render.resolution_x=1400;scene.render.resolution_y=1000;scene.render.filepath=str(root/'reviews/kunlun_closeup.png');bpy.ops.render.render(write_still=True)
report={'imported_mesh_objects':len(mesh_objects),'vertices':sum(len(o.data.vertices) for o in mesh_objects),'triangles':sum(len(o.data.polygons) for o in mesh_objects),'blender_version':bpy.app.version_string,'editable_blend':True}
(root/'reviews/blender_import_check.json').write_text(json.dumps(report,indent=2));print(report)
